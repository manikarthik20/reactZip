import React, { createContext } from 'react';
import ComB from './ComB';

const Data = createContext();

export default function ComA (){
    return(
        <div>
            <Data.Provider value={"Welcome to Ojas"}>
                <ComB/>
            </Data.Provider>
        </div>
    )
}
export {Data};
