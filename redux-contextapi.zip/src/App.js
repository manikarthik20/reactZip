
import './App.css';
import ComA from './Contextapicomponent/comA';
import Application from './reduxComponent/Aplication';


function App() {
  return (
    <div className="App">
      {/* <ComA/> */}
      <Application/>
    </div>
  );
}

export default App;
