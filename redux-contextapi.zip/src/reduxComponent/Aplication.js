import React from "react";
import { useSelector, useDispatch } from 'react-redux'
import {incNum, decNum} from './actions'

function Application (){
    const mystate = useSelector((state) => state.change);
    const dispatch = useDispatch();

    return (
        <>
        <h2>Increment/Decrement the number using Redux</h2>
        <div>
            <h1>{mystate}</h1>
            <button onClick={() => {dispatch(incNum())}}>+</button>
            <button onClick={() => {dispatch(decNum())}}>-</button>
        </div>
        </>
    )
}
export default Application;