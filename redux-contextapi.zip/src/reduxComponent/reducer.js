import change from "./fun";
import {combineReducers} from 'redux';

const rootReducer = combineReducers({change});

export default rootReducer;