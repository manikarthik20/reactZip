import React, { Component } from 'react'
import ReactDOM from 'react-dom'

class Portal extends Component {
render() {
	return ReactDOM.createPortal(
	
	document.getElementById('portal')
	);
}
}
class App extends Component {
constructor(props) {
	super(props);
	this.state = {click: 0};
	this.handleClick = this.handleClick.bind(this);
}
handleClick() {
	this.setState({
	click: this.state.click + 1
	});
}
render() {
	return (
	<div onClick={this.handleClick}
		style={{marginLeft: '10px'}}>
	<p>
		You have clicked me {this.state.click} times
	</p>
	<button style={{marginLeft: '10px'}}>
		Click
	</button>,
	</div>
	);
}
}
export default App;
