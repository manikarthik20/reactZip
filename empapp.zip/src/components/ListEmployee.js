import React, { Component } from "react";
import { Table } from "react-bootstrap";
import EmployeeService from "../services/EmployeeService";

class ListEmployee extends Component {
    constructor(props) {
        super(props)
        this.state = {
            employees: []
        }
        this.addEmployee = this.addEmployee.bind(this);
        this.editEmployee = this.editEmployee.bind(this);
        this.deleteEmployee = this.deleteEmployee.bind(this);

    }
    deleteEmployee(id){
        EmployeeService.deleteEmployee(id).then(res => {
            this.setState({
                employees:
                this.state.employees.filter(employee => employee.id !== id)
            });
        });
    }
    viewEmployee(id){
        this.props.history.push(`/view-employee/${id}`);
    }
    editEmployee(id){
        this.props.history.push(`/add-employee/${id}`);
    }
    componentDidMount(){
        EmployeeService.getEmployees().then((res) => {
            this.setState({ employees:res.data});
        });
    }
    addEmployee() {
        this.props.history.push('/add')
    }
    render() {
        return (
            <div>
                <h1 className="text-center">Employee List</h1>
                
                <br></br>
                <div className=" container">
                    <Table striped bordered hover variant="dark">
                        <thead>
                            <tr>
                                <th>Employee Name</th>
                                <th>Employee Age</th>
                                <th>Employee Salary</th>
                                <th>Employee Address</th>
                                <th>Employee Skillset</th>
                                <th>Employee Dept</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                            this.state.employees.map(employee =>
                                <tr key={employee.eid}>
                                    <td>{employee.ename}</td>
                                    <td>{employee.eage}</td>
                                    <td>{employee.esalary}</td>
                                    <td>{employee.eaddress}</td>
                                    <td>{employee.eskillset}</td>
                                    <td>{employee.edept}</td>
                                    <td>
                                        <button onClick={() => this.editEmployee(employee.id)} className="btn btn-warning">Update</button>
                                        <button style={{marginLeft:"10px"}} onClick={() => this.deleteEmployee(employee.eid)} className="btn btn-danger">Delete</button>
                                        <button style={{marginLeft:"10px"}} onClick={() => this.viewEmployee(employee.eid)} className="btn btn-info">View</button>
                                    </td>
                                </tr>

                            )}
                        </tbody>
                    </Table>
                </div>
                <div >
                    <button className="btn btn-primary"
                        onClick={this.addEmployee}>Add Employee</button>
                </div>
            </div>
        )
    }
}
export default ListEmployee;
