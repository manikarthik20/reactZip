import React, { Component } from "react";
import EmployeeService from "../services/EmployeeService";

class CreateEmployee extends Component{
    constructor(props){
        super()
        this.state={
            eid:this.props.match.params.id,
            ename:'',
            eage:'',
            esalary:'',
            eaddress:'',
            eskillset:'',
            edept:''
        }
    }
    componentDidMount(){
        if(this.state.eid === '_add'){
            return
        }else{
            EmployeeService.getEmployeeById(this.state.eid).then((res) => {
                let employee = res.data;
                this.setState({
                    ename:employee.ename,
                    eage:employee.eage,
                    esalary:employee.esalary,
                    eaddress:employee.eaddress,
                    eskillset:employee.eskillset,
                    edept:employee.edept
                });
            });
        }
        this.changeEmpName = this.changeEmpName.bind(this);
        this.changeEmpAge = this.changeEmpAge.bind(this);
        this.changeEmpSalary = this.changeEmpSalary.bind(this);
        this.changeEmpAddress = this.changeEmpAddress.bind(this);
        this.changeEmpSkillset = this.changeEmpSkillset.bind(this);
        this.changeEmpdept = this.changeEmpdept.bind(this);
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
    }
    saveOrUpdateEmployee = (e) => {
        e.prevantDefault();
        let employee={
            ename:this.state.ename,
            eage:this.state.eage,
            esalary:this.state.esalary,
            eaddress:this.state.eaddress,
            eskillset:this.state.eskillset,
            edept:this.state.edept
        };
        console.log('employee => ' + JSON.stringify(employee));
        if(this.state.eid === '_add'){
            EmployeeService.createEmployee(employee).then(res =>{
                this.props.history.push('/employees');
            });
        }else{
            EmployeeService.updateEmployee(employee,this.state.eid)
            .then(res =>{
                this.props.history.push('/employees')
            })
        }
    }
    changeEmpName = (e) => {
        this.setState({ename:e.target.value});
    }
    changeEmpAge = (e) => {
        this.setState({eage:e.target.value});
    }
    changeEmpSalary = (e) => {
        this.setState({esalary:e.target.value});
    }
    changeEmpAddress = (e) => {
        this.setState({eaddress:e.target.value});
    }
    changeEmpSkillset = (e) => {
        this.setState({eskillset:e.target.value});
    }
    changeEmpdept = (e) => {
        this.setState({edept:e.target.value});
    }
    cancel(){
        this.props.history.push('/employees');
    }
    getTitle(){
        if(this.state.eid === '_add'){
            return <h3 className="text-center">Add Employee</h3>
        }else{
            return <h3 className="text-center">Update Employee</h3>
        }
    }
    render(){
        return(
            <div>
                <br></br>
            <div className="container">
               <div className="row">
                  <div className="card col-md-6 offset-md3 offset-md-3">
                     {
                        this.getTitle()
                     }
                     <div className="card-body">
                        <form>
                           <div className="form-group">
                              <label> Employee Name:
                              </label>
                              <input placeholder="Employee Name"
                               name="employeeName" className="form-control"

                                 value={this.state.ename} onChange={this.changeEmpName} />
                           </div>
                           <div className="form-group">
                              <label> Employee Age:
                              </label>
                              <input placeholder="Employee Age"
                               name="employeeAge" className="form-control"

                                 value={this.state.eage} onChange={this.changeEmpAge} />
                           </div>
                           <div className="form-group">
                              <label> Employee Salary: </label>
                              <input placeholder="Employee Salary"
                               name="employeeSalary" className="form-control"

                                 value={this.state.esalary} onChange={this.changeEmpSalary} />
                           </div>
                           <div className="form-group">
                              <label> Employee Address: </label>
                              <input placeholder="Employee Address"
                               name="employeeAddress" className="form-control"

                                 value={this.state.eaddress} onChange={this.changeEmpAddress} />
                           </div>
                           <div className="form-group">
                              <label> Employee Skillset: </label>
                              <input placeholder="Employee Skillset"
                               name="employeeSkillset" className="form-control"

                                 value={this.state.eskillset} onChange={this.changeEmpSkillset} />
                           </div>
                           <div className="form-group">
                              <label> Employee dept: </label>
                              <input placeholder="Employee dept"
                               name="employeedept" className="form-control"

                                 value={this.state.edept} onChange={this.changeEmpdept} />
                           </div>
                           <button className="btn btn-success" onClick={this.saveOrUpdateEmployee}>Save</button>
                           <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{
                              marginLeft:
                                 "10px"
                           }}>Cancel</button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            </div>
        )
    }
}
export default CreateEmployee;