//import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
//import ListEmployee from './components/ListEmployee';
//import ListEmployee from './components/ListEmployee';
import NavBar from './components/NavBar';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
     {/* <Router>
       <Routes>
       <NavBar></NavBar>
       <Route exact path="/" component={ListEmployee}></Route>
       </Routes>
     </Router> */}
     <NavBar/>
    </div>
  );
}

export default App;
