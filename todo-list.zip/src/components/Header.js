import React from 'react'

const Header = () => {
  return (
    <div className='header'>
        <h1>Todos List</h1>
    </div>
  )
}

export default Header
