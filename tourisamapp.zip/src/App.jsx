import React from "react";
//import ToggleButtonAccess from "./components/login/ToggleButtonAccess";
//import Home from "./components/home/Home";
import LoginMain from "./components/login/LoginMain";
//import Register from "./components/login/Register";
//import ToggleButton from "./components/login/ToggleButton";

function App() {
  return (
    <div className="app">
      <LoginMain/>
      {/* <Home/> */}
      {/* <ToggleButtonAccess/> */}
      {/* <Register/> */}
      
    </div>
  );
}

export default App;
