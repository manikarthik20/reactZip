import axios from 'axios'

const USERA_REST_API_URL = 'http://localhost:8083/all';

class UserService{
    getUsers(){
        return axios.get(USERA_REST_API_URL);
    }
}
export default new UserService;