//import './App.css';
import '../login/Toggle.css';
//import LoginMain from './LoginMain';
import ToggleButton from "./ToggleButton";
//import LoginMain from "./LoginMain";

                      
// const Checked = () => <>🤪</>;
// const UnChecked = () => <>🙂</>;

const Checked = () => <>Login</>;
const UnChecked = () => <>Register</>;

function ToggleButtonAccess() {
  return (
    <div className="App">
      
        <ToggleButton  onChange={state => console.log(state)} icons={{checked: <Checked />, unchecked: <UnChecked />}} />
    
    </div>
  );
}
export default ToggleButtonAccess;
