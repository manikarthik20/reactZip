import React, { useState } from 'react'
import FormInput from './Forminput'
import '../login/LoginMain.css';


const LoginMain = () => {
 

  const [logins, setLogins] = useState({
    userName:"",
    password:"",
  });
const loginDetails = [
  {
      id:1,
      name:"userName",
      type:"text",
      placeholder:"Username",
      errorMessage:"UserName Should be 3-16 characters and shouldn't include any special character!",
      label:"Username",
      pattern:`^[A-Za-z0-9]{3,16}$`,
      required:true,

  },
  {
      id:2,
      name:"password",
      type:"password",
      placeholder:"Password",
      errorMessage:"Password Should be 8-20 characters and innclude at least 1 letter , 1 number and 1 special character!",
      label:"Password",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required:true,
  }
]
  
//   const handleSubmit = e => {
//     e.preventDefault();

//     axios.post('http://localhost:8083/saveUser', values)
//         .then((res) => {
//             console.log(res.data)
//         }).catch((error) => {
//             console.log(error)
//         });
//         console.log(values);
//         alert("You Successfully registerd !");
// }



// useEffect(() => {
//  handleSubmit();
      
// }, []);

// const handleSubmit = (e) => {
//   axios.post('http://localhost:8083/saveUser', values)
//   .then(response =>console.log(response.data));
//   console.log(values);
// }



 const handleLoginChange = (e) => {
  e.preventDefault();
  setLogins({
    ...logins, [e.target.name] : e.target.value,
  })
 }

 const submitHandler = (e) => {
  e.preventDefault();
  console.log(logins);
 }

  return (
    <div className='loginApp'>
      <div >
      <form onSubmit={submitHandler} className='loginForm'>
        <h1 className='loginHeader'>Login</h1>
        {loginDetails.map((login)=>(
          <FormInput key={login.id}
          {...login} value={logins[login.name]}
          onChange = {handleLoginChange}
          />
        ))}
        <button className='loginButton' type='Submit'>Login</button>
      </form>
      </div>
    </div>
  )
}

export default LoginMain;


// ===============================for not rerendering =======================
//=======================we can use useref() also==========================
// import React, { useRef } from 'react'
// import FormInput from './Forminput'
// import '../login/LoginMain.css';

// const LoginMain = () => {
//   ///const [userName, setUserName] = useState("");
  

  
//   console.log("re-render");

//   const handleSubmit = (e) =>{
//     e.preventDefault();
//    const data = new FormData(e.target)
//    console.log(Object.fromEntries(data.entries()));
//   }
//   return (
//     <div className='app'>
//       <form onSubmit={handleSubmit}>
//         <FormInput name="username" placeholder="Username" />
//         <FormInput name="Email"  placeholder="Email"/>
//         <FormInput name="fullName" placeholder="Full Name"/>
//         <FormInput name="Somthing" placeholder="somthing"/>
//         <button >Submit</button>
//       </form>
//     </div>
//   )
// }

// export default LoginMain;




