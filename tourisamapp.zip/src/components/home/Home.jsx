import React from 'react'
import '../home/Home.css';

function Home() {
    return (
        <>

                {/* <!--===========Nav Bar=================--> */}
                <section className="nav-bar">
                    <div className="logo">Go Trip</div>
                    <ul className="menu">
                        <li>home</li>
                        <li>tours</li>
                        <li>package</li>
                        <li>blog</li>
                        <li>about us</li>
                        <li>contact us</li>
                    </ul>
            </section>
            {/* <!--===============Banner================--> */}
            <section className="banner">
                <div className="banner-text-item">
                    <div className="banner-heading">
                        <h1>Find your Next tour!</h1>
                    </div>
                    <form className="form">
                        <input type="text" list="mylist" placeholder="Where would you like to go?"/>
                            <datalist id="mylist">
                                <option>London</option>
                                <option>Canada</option>
                                <option>Monaco</option>
                                <option>France</option>
                                <option>Japan</option>
                                <option>Switzerland</option>
                                <option>Seoul</option>
                            </datalist>
                            <input type="date" className="date"/>
                                <p className="book">book</p>
                            </form>
                        </div>
                    </section>

                    {/* <!--=========Services===============--> */}
                    <section className="services">
                        <div className="service-item">
                            <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293634/tour-guide_onzla9.png" alt=''/>
                                <h2>8000+ Our Local Guides</h2>
                        </div>
                        <div className="service-item">
                            <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293738/reliability_jbpn4g.png" alt=''/>
                                <h2>100% Trusted Tour Agency</h2>
                        </div>
                        <div  className="service-item">
                            <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293635/experience_a3fduk.png" alt=''/>
                                <h2>28+ Years of Travel Experience</h2>
                        </div>
                        <div className="service-item">
                            <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293634/feedback_s8z7d9.png" alt=''/>
                                <h2>98% Our Travelers are Happy</h2>
                        </div>
                    </section>
                    {/* <!--==============Places===================--> */}
                    <section className="places">
                        <div className="places-text">
                            <small>FEATURED TOURS PACKAGES</small>
                            <h2>Favourite Places</h2>
                        </div>

                        <div className="cards">
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293736/james-wheeler_xqmq2y.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Vancouver, Canada</p>
                                    </div>
                                </div>

                            </div>
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293755/paris_uj8wum.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Paris, France</p>
                                    </div>
                                </div>

                            </div>
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293955/monaco_usu7xb.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Monaco, Monaco</p>
                                    </div>
                                </div>

                            </div>
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293874/switzerland_tubxcm.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Bern, Switzerland</p>
                                    </div>
                                </div>

                            </div>
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293673/korea_bxrcj5.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Seoul, South Korea</p>
                                    </div>
                                </div>

                            </div>
                            <div className="card">
                                <div className="zoom-img">
                                    <div className="img-card">
                                        <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293673/night-4336403_1920_demehp.jpg" alt=''/>
                                    </div>
                                </div>

                                <div className="text">
                                    <span className="rating">&#11088;&#11088;&#11088;&#11088;&#11088;</span>
                                    <h2>The Dark Forest Adventure</h2>
                                    <p className="cost">$1870 / Per Person</p>
                                    <div className="card-box">
                                        <p className="time">&#128339; 3 Days</p>
                                        <p className="location">&#9992; Tokyo, japan</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {/* <!--===========About Us===============--> */}
                    <section className="about">
                        <div className="about-img">
                            <img  src="https://res.cloudinary.com/dxssqb6l8/image/upload/v1605293719/outdoor_tjjhxk.jpg" alt=''/>
                        </div>
                        <div className="about-text">
                            <small>ABOUT OUR COMPANY</small>
                            <h2>We are Go Trip Ravels Support Company</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                Ut enim ad minim veniam, quis nostrud</p>

                            <label><input type="checkbox" />Lorem ipsum dolor sit amet</label>
                            <label><input type="checkbox" />consectetur adipisicing elit</label>
                            <label><input type="checkbox" />Architecto atque consequuntur</label>
                            <label><input type="checkbox" />cupiditate doloremque ducimus</label>
                            <p >ABOUT US</p>
                        </div>
                    </section>

                    {/* <!--===========Footer=================--> */}
                    <div className="footer">
                        <div className="links">
                            <h3>Quick Links</h3>
                            <ul>
                                <li>Offers & Discounts</li>
                                <li>Get Coupon</li>
                                <li>Contact Us</li>
                                <li>About</li>
                            </ul>
                        </div>
                        <div className="links">
                            <h3>New Products</h3>
                            <ul>
                                <li>Woman Cloth</li>
                                <li>Fashion Accessories</li>
                                <li>Man Accessories</li>
                                <li>Rubber made Toys</li>
                            </ul>
                        </div>
                        <div className="links">
                            <h3>Support</h3>
                            <ul>
                                <li>Frequently Asked Questions</li>
                                <li>Report a Payment Issue</li>
                                <li>Terms & Conditions</li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                    </div>
        </>
    )
}

export default Home
