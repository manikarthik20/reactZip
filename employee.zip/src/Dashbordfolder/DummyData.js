export const userData = [
  {
    name: 'Jan',
    "Active User": 4000,
  },
  {
    name: 'Feb',
    "Active User": 3000,
  },
  {
    name: 'Mar',
    "Active User": 5000,
  },
  {
    name: 'Apr',
    "Active User": 4000,
  },
  {
    name: 'May',
    "Active User": 3000,
  },
  {
    name: 'Jun',
    "Active User": 2000,
  },
  {
    name: 'July',
    "Active User": 4000,
  },
  {
    name: 'Aug',
    "Active User": 3000,
  },
  {
    name: 'Sep',
    "Active User": 4000,
  },
  {
    name: 'Oct',
    "Active User": 1000,
  },
  {
    name: 'Nov',
    "Active User": 4000,
  },
  {
    name: 'Dec',
    "Active User": 3000,
  },

];

export const productData = [
  {
    name: 'Jan',
    "Sales": 4000,

  },
  {
    name: 'Feb',
    "Sales": 3000,
  },
  {
    name: 'Mar',
    "Sales": 5000,
  },
  {
    name: 'Apr',
    "Sales": 4000,
  },
  {
    name: 'May',
    "Sales": 3000,
  },
  {
    name: 'Jun',
    "Sales": 2000,
  },
  {
    name: 'July',
    "Sales": 4000,
  },
  {
    name: 'Aug',
    "Sales": 3000,
  },
  {
    name: 'Sep',
    "Sales": 4000,
  },
  {
    name: 'Oct',
    "Sales": 1000,
  },
  {
    name: 'Nov',
    "Sales": 4000,
  },
  {
    name: 'Dec',
    "Sales": 3000,
  },

];


export const userRows = [
  {
    id: 1,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 2,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 3,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 4,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 5,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 6,
    username: "Kumar Goud ",
    avatar: "https://wallpapercave.com/wp/wp6538674.jpg",
    email: "kumar123@gmail.com",
    status: "active",
    transaction: "$120.00",
  },

];

export const productRows = [
  {
    id: 1,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },
  {
    id: 2,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },
  {
    id: 3,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },
  {
    id: 4,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },
  {
    id: 5,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },
  {
    id: 6,
    name: "Apple Airpods",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyStdws5fkVM1dGfR6g2lhZY3MQabzM3-wOx3sSZMpjUB4vneddBAKRN6eGRfWo4xH-1s&usqp=CAU",
    stock: "123",
    status: "active",
    price: "$120.00",
  },

];