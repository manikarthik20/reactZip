import React, { Component } from 'react'

export default class Frontend extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to Frontend</h1>
      </div>
    )
  }
}
