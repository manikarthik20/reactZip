import React, { Component } from 'react'

export default class Java extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to Java</h1>
      </div>
    )
  }
}
