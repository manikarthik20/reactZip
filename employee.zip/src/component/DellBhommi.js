import React, { Component } from 'react'

export default class DellBhommi extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to boomi</h1>
      </div>
    )
  }
}
