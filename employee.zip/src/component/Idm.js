import React, { Component } from 'react'

export default class Idm extends Component {
  render() {
    return (
      <div>
        <h1> Welcome to Idm</h1>
      </div>
    )
  }
}
