import React, { Component } from 'react'

export default class Fullstack extends Component {
  render() {
    return (
      <div>
        <h1>Welocme to Fullstack</h1>
      </div>
    )
  }
}
