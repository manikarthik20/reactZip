import logo from './logo.svg';
import './App.css';
import WithOutCallBack from './components/withoutcallback';
import WithcallBack from './components/withCallBack';

function App() {
  return (
    <div className="App">
      <WithOutCallBack/>
      {/* <WithcallBack/> */}
    </div>
  );
}

export default App;
