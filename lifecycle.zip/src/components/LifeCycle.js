import React, { Component } from 'react'

 class LifeCycle extends Component {
     constructor(props){
         super(props);
         console.log("This is Constructor")
         this.state = {hello:"World"};
     }
     componentDidMount(){
         console.log("This is componentDidMount");
     };    
     componentDidCatch(){
         console.log("This is ComponentDid Catch");
     };
     componentWillUnmount(){
         console.log("This is component Will Unmount");
     };
     changeState(){
         this.setState({
             hello:"Mani !"
         });
     }
  render() {
      console.log("This is render method ");
    return (
      <div>
        <h1>Hello {this.state.hello}</h1>
        <h2><a onClick={this.changeState.bind(this)}>Press Here</a></h2>
      </div>
    )
  }
  shouldComponentUpdate(nextProps,nextState){
      console.log("This is shouldComponentUpdate()");
      return true;
  }
  componentDidUpdate(){
      console.log("This is ComponentDidUpdate()")
  }
}
export default LifeCycle;
