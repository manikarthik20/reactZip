import logo from './logo.svg';
import './App.css';
import LifeCycle from './components/LifeCycle';

function App() {
  return (
    <div className="App">
      <LifeCycle/>
    </div>
  );
}

export default App;
